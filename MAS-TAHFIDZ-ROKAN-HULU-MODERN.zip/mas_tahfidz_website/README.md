MAS TAHFIDZ ROKAN HULU - Madrasah Modern (Static Website)
--------------------------------------------------------

Cara pakai:
1. Upload seluruh isi folder ini ke repository GitHub (branch: main).
2. Aktifkan GitHub Pages di Settings -> Pages -> pilih branch 'main' dan folder '/'.
3. Website akan tersedia: https://<username>.github.io/<repository>

Edit konten:
- Untuk menambah berita, buat file baru di folder /posts/ (format HTML).
- Untuk menambah alumni, gunakan halaman /alumni.html (tersimpan di browser) atau unggah /data/alumni.json.
- Untuk mengubah teks, edit file HTML pada repo.
